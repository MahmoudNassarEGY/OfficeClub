package OfficeClub;


import java.io.IOException;
import java.net.UnknownHostException;

import Client.Client;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

public class RegForm extends Application {

	String checkUser, checkPw, checkEmail;
	Scene loginPage, RegForm, UserList, textWindow;
	Stage accountPage;
	protected AlertType alertType;
	protected String title;
	static Client client;

	public RegForm(Client cl) {
		// TODO Auto-generated constructor stub
		super();
		this.client = client;
	}

	public static void main(String[] args) throws UnknownHostException, IOException {

		client = new Client("127.0.0.1");
		boolean rs = client.connect();

		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		accountPage = primaryStage;

		BorderPane bp = new BorderPane();
		bp.setPadding(new Insets(10, 50, 50, 50));

		// Adding HBox
		HBox hb = new HBox();
		hb.setPadding(new Insets(20, 20, 20, 30));

		// Adding GridPane
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets(20, 20, 20, 20));
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Implementing Nodes for GridPane
		// Label lblFname = new Label("First Name");
		// final TextField textFname = new TextField();
		Label lblLname = new Label("User Name");
		final TextField textUserName = new TextField();
		Label lblUserName = new Label("Email");
		final TextField newEmail = new TextField();
		Label lblPassword = new Label("Password");
		final PasswordField pf = new PasswordField();
		Button btSubmit = new Button("Submit");
		Button btBack = new Button("Back");

		primaryStage.close();

		btBack.setOnAction(e -> {
			primaryStage.close();
			new LoginForm().start(new Stage());

		}); // links to newUser page

		final Label lblMessage = new Label();

		// Adding Nodes to GridPane layout (puts in column-index and row-index)
		// gridPane.add(lblFname, 0, 0);
		// gridPane.add(textFname, 1, 0);
		gridPane.add(lblLname, 0, 1);
		gridPane.add(textUserName, 1, 1);
		gridPane.add(lblUserName, 0, 2);
		gridPane.add(textUserName, 1, 2);
		gridPane.add(lblPassword, 0, 3);
		gridPane.add(pf, 1, 3);
		gridPane.add(btSubmit, 6, 5);
		gridPane.add(lblMessage, 1, 4); // this is lable created if user exist
		gridPane.add(btBack, 6, 6);

		// Reflection for gridPane
		Reflection r = new Reflection();
		r.setFraction(0.7f);
		gridPane.setEffect(r);

		// DropShadow effect
		DropShadow dropShadow = new DropShadow();
		dropShadow.setOffsetX(5);
		dropShadow.setOffsetY(5);

		// Adding text and DropShadow effect to it
		Text text = new Text("<Register to Login>");
		text.setFont(Font.font("Courier New", FontWeight.BOLD, 28));
		text.setEffect(dropShadow);

		// Adding text to HBox
		hb.getChildren().add(text);

		// Add ID's to Nodes for your css file
		bp.setId("bp");
		gridPane.setId("root");
		// btnLogin.setId("btnLogin");
		text.setId("text");
		btSubmit.setId("createAcc");
		btBack.setId("back");

		// Add HBox and GridPane layout to BorderPane Layout
		bp.setTop(hb);
		bp.setCenter(gridPane);

		btSubmit.setOnAction(e -> {

			checkUser = textUserName.getText().toString();
			checkEmail = newEmail.getText().toString();
			checkPw = pf.getText().toString();
			boolean newUser = false;

			if ((textUserName.getText().isEmpty()) || (newEmail.getText().isEmpty()) || (pf.getText().isEmpty())) {

				lblMessage.setText("Please check the required field!!");
				lblMessage.setTextFill(Color.RED);

			}

			if (newUser) {
				newUser = client.create_account(checkUser, checkUser, checkPw);

				primaryStage.close();
				lblMessage.setText("Account created successfully! You can now 'login' ");
				lblMessage.setTextFill(Color.GREEN);
				// new UserList().start(new Stage()); //mahmoud page(UserList) loads!

			}
			if (!newUser) {
				lblMessage.setText("Please check the required field!!");
				lblMessage.setTextFill(Color.RED);

				textUserName.setText("");
				newEmail.setText("");
				pf.setText("");

			}

		});

		// Adding BorderPane to the scene and loading CSS
		Scene scene = new Scene(bp);
		primaryStage.setTitle("Registration Form");
		scene.getStylesheets().add(getClass().getClassLoader().getResource("login.css").toExternalForm());
		primaryStage.setScene(scene);
		// making the stage resizeable
		primaryStage.titleProperty()
				.bind(scene.widthProperty().asString().concat(" : ").concat(scene.heightProperty().asString()));
		primaryStage.setResizable(false);
		primaryStage.show();

	}
}
