/*
 * Zayyan Ahmer
 * This is server and working with database (SQL/SQLite)
 * This is where it connect with all client and send message to each.
 */

package Server;

import java.io.*; 
import java.util.*; 
import java.net.*; 
import java.sql.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

enum status{
	online,
	offline,
	busy,
	afk
};
// Server class 
public class Server 
{ 
	//Local area only.
	static String[] ip_whitelist = {"199.212.53.0","199.212.54.0","199.212.55.0"};
	
	
	// Vector to store active clients 
	static Vector<ClientHandler> ar = new Vector<>(); //list of all client that connect to.. 
	// counter for clients 
	static int i = 0; 
	static Connection db;
	
	public static void startup() {
		/*
		 * Creating  Tables if they dont exists.
		 * Account 
		 * 	id: int -  unique id
		 * 	username: string - username for people to recongized you
		 *  email: string - email to login
		 * 	pass: string - password to login, format in hash
		 * 	create_at: int - timestamp of account created
		 * 	last_seen: int - timestamp of last time user was online
		 * 	status: int - status of user, online etc using ENUM idea.
		 * 
		 * Channel
		 * id:int - unique id
		 * name:string - name of channel
		 * created_at:int - timestamp of channel created.
		 * owner_id: int - Account ID of ownership for groups. Null.
		 * 
		 * Channel members
		 * id:int - channel id
		 * author_id - author id from Account
		 * 
		 * Message
		 * id: int - unqiue key for message
		 * author_id: int - author id from Account so u know who
		 * channel_id: int - channel id from Channel so u know where
		 * content: string - content of message that was sent
		 * created_at: int - timestamp  of message was created
		 * edit_at: int - timestamp of edited message if it it was edit
		 */  
		try {
			DatabaseMetaData meta = db.getMetaData();
			System.out.println("Driver name is " + meta.getDriverName());
			Statement smt = db.createStatement();
			boolean r;
			
			//Create account table
			String Sql = "CREATE TABLE IF NOT EXISTS Account (\n"
					+ "id integer PRIMARY KEY, \n"
					+ "username text NOT NULL, \n"
					+ "email text NOT NULL, \n"
					+ "pass textt NOT NULL, \n"
					+ "created_at integer NOT NULL, \n"
					+ "last_seen integer NOT NULL, \n"
					+ "status integer);" ;
			r = smt.execute(Sql);
			//Create Channel table
			Sql = "CREATE TABLE IF NOT EXISTS Channel (\n"
					+ "id integer PRIMARY KEY,\n"
					+ "name text, \n"
					+ "owner_id integer, \n"
					+ "created_at integer NOT NULL," //so we know who create groups.
					+ "FOREIGN KEY(owner_id) REFERENCES Account(id));";
			r = smt.execute(Sql);
			//create channel list of members.
			Sql = "CREATE TABLE IF NOT EXISTS Channel_Members (\n"
					+ "id integer NOT NULL, \n"
					+ "author_id integer NOT NULL, \n"
					+ "FOREIGN KEY (id) REFERENCES Channel(id),\n"
					+ "FOREIGN KEY (author_id) REFERENCES Account(id));";
			r = smt.execute(Sql);
			Sql = "CREATE TABLE IF NOT EXISTS Message(\n"
					+ "id integer PRIMARY KEY, \n"
					+ "author_id integer NOT NULL, \n"
					+ "channel_id integer NOT NULL, \n"
					+ "content text NOT NULL, \n"
					+ "created_at integer NOT NULL, \n"
					+ "edit_at integer, \n"
					+ "FOREIGN KEY (author_id) REFERENCES Account(id),\n"
					+ "FOREIGN KEY (channel_id) REFERENCES Channel(id));";
			r = smt.execute(Sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//end of catch.
		
				
	}//end of start up
	
	public static String hash(String pass) {
		return pass; //temp for now, we will has it later.
	}//end of hash password
	
	

	public static ResultSet get_all_name(String table) throws SQLException {
		//This allow you get all result from table u enter, such as Account etc no filter.
		PreparedStatement ptsmt = db.prepareStatement("SELECT *  from ?");
		ptsmt.setString(1, table);
		return ptsmt.executeQuery();
	}//end of getting all name list.
	public static ResultSet get_all_user() throws SQLException {
		//This allow you get all result from table u enter, such as Account etc no filter.
		PreparedStatement ptsmt = db.prepareStatement("SELECT *  from Account");
		return ptsmt.executeQuery();
	}//end of getting all name list.
	//Getting account by username or email / id
	public static ResultSet get_account(String name,boolean isEmail) throws SQLException {
		//Searching for account by provide email
		String sql;
		//IF it email, we will find data from conditions email which is unqiue else username
		if( isEmail) sql = "SELECT * from Account where email = ?";
		else  sql = "SELECT * from Account where username = ?";
		PreparedStatement pstmt;
		pstmt = db.prepareStatement(sql);
		pstmt.setString(1, name);
		return pstmt.executeQuery();
	}//end of getting account by name/email
	
	public static ResultSet get_account(int id) throws SQLException {
		//searching for account by providing ID
		String sql = "SELECT * from Account where id = ?";
		PreparedStatement pstmt;
		pstmt = db.prepareStatement(sql);
		pstmt.setInt(1, id);
		return pstmt.executeQuery();
	}//end of get account via id
	
	//update account status
	public static boolean update_account_status(int id,int status) throws SQLException {
		String sql = "UPDATE Account SET status = ? WHERE id = ?";
		PreparedStatement pmt = db.prepareStatement(sql);
		pmt.setInt(1, status);
		pmt.setInt(2, id);
		return pmt.execute();
	}//end of updating status
	
	public static boolean update_account_seen(int id) throws SQLException {
		String sql = "UPDATE Account SET last_seen = ? WHERE id = ?";
		PreparedStatement pmt = db.prepareStatement(sql);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		pmt.setTimestamp(1, timestamp);
		pmt.setInt(2, id);
		return pmt.execute();
	}//end of last seen.
	
	public static int create_account(JSONObject data) throws SQLException {
		String user = (String) data.get("Username");
		String pass= (String) data.get("Password");
		String email = (String) data.get("Email");
		return create_account(user,email,pass);
	}//end of create account
	
	public static int create_account(String username, String email, String pass) throws SQLException {
		ResultSet rs = get_account(email,true);
		if(rs.isBeforeFirst()) return 0; // meaning it exists and shouldnt be.
		rs.close();
    	String sql = "INSERT INTO Account(username, email,pass,created_at,last_seen) VALUES (?,?,?,?,?)";
		PreparedStatement pstmt = db.prepareStatement(sql);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		pstmt.setString(1,username);
		pstmt.setString(2,email);
		pstmt.setString(3,hash(pass));
		pstmt.setTimestamp(4, timestamp);
		pstmt.setTimestamp(5, timestamp);
		pstmt.execute();
		pstmt.close();
        rs = get_account(email,true);
        System.out.println("Checking");
        if(!rs.isBeforeFirst()) return 0;
        int temp = rs.getInt("id");
        rs.close();
		return temp;
	}//end of creating account.
	
	public static ResultSet get_all_group(int id) throws SQLException {
		//This is for only one that user are IN.
		String sql = "SELECT * from Channel LEFT JOIN Channel_Members "
				+ "ON Channel.id = Channel_Members.id"
				+ " WHERE Channel_Members.id = ? AND " 
				+ "Channel.name != NULL";
		PreparedStatement psmt = db.prepareStatement(sql);
		psmt.setInt(1, id);
		return psmt.executeQuery();
	}//end of get all group from this user is in.
	
	
	public static ResultSet get_channel(int id) throws SQLException{
		String sql = "SELECT * from Channel where id = ?";
		PreparedStatement pstmt;
		pstmt = db.prepareStatement(sql);
		pstmt.setInt(1, id);
		return pstmt.executeQuery();
	}//end of getting channel.
	
	public static ResultSet get_channel_list(int id) throws SQLException{
		String sql = "SELECT * from Channel_Members where id = ?";
		PreparedStatement pstmt;
		pstmt = db.prepareStatement(sql);
		pstmt.setInt(1, id);
		return pstmt.executeQuery();
	}//end of getting channel list
	//Create channel here
	/*
	 * Channel
	 * id:int - unique id
	 * name:string - name of channel
	 * created_at:int - timestamp of channel created.
	 * 
	 * we will create name and then created_at
	 * once we do that, then we will make list of members in that channel via channel id and author id
	 */
	public static int create_channel(int user_id, int other_id)  throws SQLException{
    	String sql = "INSERT INTO Channel(created_at) VALUES (?)";
		PreparedStatement pstmt = db.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		pstmt.setTimestamp(1, timestamp);
		pstmt.execute();
		ResultSet rs;
		try {
			 rs = pstmt.getGeneratedKeys();
		}catch(SQLException e) { 
			e.printStackTrace();
			return 0;}
		rs.next();
		int channel_id = rs.getInt(1);
		//then we add them to list.
		add_channel_members(channel_id,user_id);
		 add_channel_members(channel_id,other_id);
		return channel_id;
//	    return false;
	}//end of create_channel
	
	public static boolean remove_channel(int chan_id) throws SQLException {
		String sql = "DELETE FROM Channel_Members WHERE id = ?";
		PreparedStatement pmt = db.prepareStatement(sql);
		pmt.setInt(1, chan_id);
		boolean first = pmt.execute();
		sql = "DELETE FROM Channel WHERE id = ?";
		pmt = db.prepareStatement(sql);
		pmt.setInt(1, chan_id);
		boolean second = pmt.execute();
		return first && second;
	}//end of remove channel/groups.
	
	
	public static int create_group(String name,int owner_id) throws SQLException {
    	String sql = "INSERT INTO Channel(name,owner_id,created_at) VALUES (?,?,?)";
		PreparedStatement pstmt = db.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		pstmt.setString(1,name);
		pstmt.setInt(2, owner_id);
		pstmt.setTimestamp(3, timestamp);
		ResultSet rs;
		try {
			 rs = pstmt.getGeneratedKeys();
		}catch(SQLException e) { 
			e.printStackTrace();
			return -1;}
		rs.next();
		return rs.getInt(1);
	}//end of create_channel
	
	
	/*
	 * This here below function are channel + members list
	 * so with channel ID, we can know which members are in that channel etc.
	 * 
	 */
	public static int get_private_channel_id(int author1_id,int author2_id) throws SQLException {
		String sql = "SELECT id FROM Channel_Members where author_id = ? OR author_id = ?";
		PreparedStatement pmt = db.prepareStatement(sql);
		pmt.setInt(1, author1_id);
		pmt.setInt(2, author2_id);
		ResultSet rs = pmt.executeQuery();
		if(!rs.isBeforeFirst()) return 0;
		rs.next();
		return rs.getInt(1); //if 0 then it is null
	}//end of getting private channel id between two party.
	
	public static boolean add_channel_members(int chan_id,int member_id) throws SQLException {
		String sql = "INSERT INTO Channel_Members(id,author_id) VALUES (?,?)";
		PreparedStatement pmt = db.prepareStatement(sql);
		pmt.setInt(1,chan_id);
		pmt.setInt(2, member_id);
		return pmt.execute();
	}//end of adding members to group channel
	
	public static boolean remove_channel_members(int chan_id, int member_id) throws SQLException {
		String sql = "DELETE FROM Channel_Members WHERE id = ? AND author_id = ?";
		PreparedStatement pmt = db.prepareStatement(sql);
		pmt.setInt(1, chan_id);
		pmt.setInt(2, member_id);
		return pmt.execute();
	}//end of removing members from groups
	
	//get history msg
	public static ResultSet get_msg_history(int chan_id) throws SQLException{
		String sql = "SELECT * FROM Message WHERE channel_id = ?";
		PreparedStatement pmt = db.prepareStatement(sql);
		pmt.setInt(1, chan_id);
		return pmt.executeQuery();
	}//end of msg history
	
	//Store message here
	public static ResultSet add_msg(int author_id, int chan_id, String cnt) throws SQLException {
		String sql = "INSERT INTO Message(author_id,channel_id,content,created_at) VALUES (?,?,?,?)";
		PreparedStatement pmt = db.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		pmt.setInt(1, author_id);
		pmt.setInt(2, chan_id);
		pmt.setString(3, cnt);
		pmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
		pmt.execute();
		ResultSet rs;
		try {
			 rs = pmt.getGeneratedKeys();
			 pmt.close();
			 rs.next();
			 return get_msg(rs.getInt(1));
		}catch(SQLException e) { 
			e.printStackTrace();
			return null;
		}
	}//end of add msg
	
	public static ResultSet get_msg(int msg_id) throws SQLException {
		String sql = "SELECT * from Message where id = ?";
		PreparedStatement pstmt = db.prepareStatement(sql);
		pstmt.setInt(1, msg_id);
		ResultSet rs = pstmt.executeQuery();
		return rs;
	}
	
	public static JSONObject login(JSONObject data) throws SQLException {
		JSONObject result = new JSONObject();
		result.put("Status","login_reply");
		ResultSet rs = Server.get_account((String) data.get("email"),true);
		if(!rs.isBeforeFirst()) { 
			System.out.println("Account not found");
			result.put("success",false);
			return result;}
		String email= (String) data.get("email");
		String pass = (String) data.get("Password");
		System.out.println("RS Show " + rs.getRow());

		while(rs.next()) {
			System.out.println("Loops: RS Show " + rs.getRow());
			System.out.println(rs.getString("username") +  "  and  " + rs.getString("pass") );
			//if we found matching username and pass, then return true.
			if( rs.getString("email").equals(email) 
					&& rs.getString("pass").equals(hash(pass))){
				result.put("success", true);
				result.put("username",rs.getString("username"));
				result.put("user_id",rs.getInt("id"));
				return result;
				}
		}//end of while loops
		result.put("success",false);
		return result; //nothing found.
	}//end of login method
	
	public static boolean is_in_whitelist(String ip) {
		if(ip.contains("127.0.0.1")) return true;
		for(String wl:ip_whitelist) {
			//IP is like xxx.xxx.xxx.xxx, we only want first 3 split, so that 3 + 3 + 3 + 3 (dot) =12.
			//so substring is 0 to 12+1
			//1,13 for IP cuz of /xxx.xxx----
			if( wl.substring(0,13).contentEquals(ip.substring(1, 13))) return true;
		}
		return false;
	};
	
	public static void main(String[] args) throws SQLException, IOException 
	{ 
		// server is listening on port 1234 
		ServerSocket ss = null;
		try {
			ss = new ServerSocket(1234);
		} catch (IOException e) {
			System.out.println("You are likely already having other server running, One server instance can only run at a time");
			return;
		} 
		File isFolderExists = new File("Database");
		if(!isFolderExists.exists()) isFolderExists.mkdir();
		db = DriverManager.getConnection("jdbc:sqlite:Database/database.db");
		Socket s; 
		
		startup();
		// running infinite loop for getting 
		// client request 
		while (true)
		{ 
			// Accept the incoming request 
			s = ss.accept(); 
			System.out.println(s.getRemoteSocketAddress().toString());
			if(!is_in_whitelist(s.getRemoteSocketAddress().toString())) {
				s.close();
				System.out.println("Denied this IP!");
				return; //ignore this
			}

			System.out.println("New client request received : " + s); 
			// obtain input and output streams 
			DataInputStream dis = new DataInputStream(s.getInputStream()); 
			DataOutputStream dos = new DataOutputStream(s.getOutputStream()); 
			
			System.out.println("Creating a new handler for this client..."); 

			// Create a new handler object for handling this request. 
			ClientHandler mtch = new ClientHandler(s,"client " + i, dis, dos); 

			// Create a new Thread with this object. 
			Thread t = new Thread(mtch); 
			
			System.out.println("Adding this client to active client list"); 

			// add this client to active clients list 
			ar.add(mtch); 

			// start the thread. 
			t.start(); 

			// increment i for new client. 
			// i is used for naming only, and can be replaced 
			// by any naming scheme 
			i++; 

		}//end of while loops 
	} //end of main
} //end of class

// ClientHandler class 
class ClientHandler implements Runnable 
{ 
	Scanner scn = new Scanner(System.in); 
	String name;
	int user_id;
	final DataInputStream dis; 
	final DataOutputStream dos; 
	Socket s; 
	boolean isloggedin; 
	
	// constructor 
	public ClientHandler(Socket s, String name, 
							DataInputStream dis, DataOutputStream dos) { 
		this.dis = dis; 
		this.dos = dos; 
		this.name = name;
		this.s = s; 
		this.isloggedin=true;  
	} 
	private void send(JSONObject data) throws IOException {dos.writeUTF(data.toJSONString());}
	
	private void signout() {
		System.out.println("Client: " + this.name + " has signed out and current capacity is " + Server.ar.size());
		this.isloggedin=false; 
		for(int i = 0; i < Server.ar.size(); i ++) {
			if(Server.ar.get(i) == this) {
				Server.ar.remove(i);//remove from it list so we dont build up mem.
				return;
			}//end of if
		}//end of loops
		try {
			this.s.close();
			Server.update_account_seen(user_id);
			// closing resources 
			this.dis.close(); 
			this.dos.close(); 

		} catch (IOException | SQLException e1) {
			return;
		}//end of catch
	}//end of signout

	private void login(JSONObject data) throws SQLException, IOException {
		JSONObject result  = new JSONObject();
		//if login success match, then return true else false
		result = Server.login(data);
		if((boolean)result.get("success")){
		name = (String)result.get("username");
		user_id = (int)result.get("user_id");
		}
		send(result);
	}//end of login
	
	private void create_account(JSONObject data) throws SQLException, IOException{
		JSONObject result = new JSONObject();
		result.put("Status","create_account_reply");
		this.user_id = Server.create_account(data);
		if(user_id != 0){
			result.put("Success",true);
			result.put("User_ID",user_id);
		}
		else result.put("Success",false);
		send(result);
		}//end of create account 
	
	private void create_channel(JSONObject data) throws SQLException, IOException {
		int other_id = ((Long)data.get("other_user_id")).intValue();
		int channel_id = Server.get_private_channel_id(user_id, other_id);
		boolean result = false;//false by default, if it doesn't exists, we will make it true.
		JSONObject send_data = new JSONObject();
		if(channel_id == 0)
			channel_id  = Server.create_channel(this.user_id,other_id);
		else {
			send_data.put("Reason","Already exists");
		}
		send_data.put("Status", "create_channel_reply");
		send_data.put("Success",channel_id > 0);
		send_data.put("channel_id", channel_id);
		send(send_data);
	}//end of create channel
	
	public void get_private_channel(JSONObject data) throws SQLException, IOException {
		int id = Server.get_private_channel_id(user_id,((Long)data.get("other_id")).intValue());
		JSONObject result = new JSONObject();
		result.put("status", "get_pm_reply");
		result.put("success", (id > 0)?true:false);
		send(result);
	}
	private void get_all_group(JSONObject data) throws SQLException, IOException {
		ResultSet rs = Server.get_all_group(user_id);
		JSONArray info = new JSONArray();
		JSONObject temp;
		if(!rs.isBeforeFirst()) {//doesn't contain any data
			temp = new JSONObject();
			temp.put("Success",false);
			dos.writeUTF(temp.toJSONString());
		}//end of doesn;t contain
		//here we can assume THERE IS data in.
		while(rs.next()){
			temp = new JSONObject();
			temp.put("id",rs.getInt("id"));
			temp.put("name",rs.getString("name"));
			temp.put("created_at",rs.getTime("created_at"));
			temp.put("owner_id",rs.getInt("owner_id"));
			info.add(temp);
		}//end of while loops
		//once we done putting data inside. we will now put them into one more JSON with success.
		temp = new JSONObject();
		temp.put("Success",true);
		temp.put("data", info);
		send(temp);
	}//end of get all group
	
	private void create_group(JSONObject data) throws SQLException, IOException {
		JSONObject result = new JSONObject();
		result.put("Status", "create_group_reply");
		int group_id = Server.create_group((String) data.get("name"), user_id);
		result.put("Success", group_id > 0);
		result.put("group_id", group_id);
		send(result);
	}
	private boolean isOwnerChannel(int chan_id) {
		try {
			ResultSet rs = Server.get_channel(chan_id);
			rs.next();
			return rs.getInt("owner_id") == user_id;
		} catch (SQLException e) {
			return false;
		}
	}//end of isOwnerChannel
	
	private void add_member_group(JSONObject data) throws SQLException, IOException {
		int chan_id = ((Long) data.get("channel_id")).intValue();
		int other_id = ((Long) data.get("other_user_id")).intValue();
		JSONObject result = new JSONObject();
		result.put("Status", "add_member_reply");
		if(!isOwnerChannel(chan_id)) {
			result.put("Success", false);
		}//end of if
		else {
			result.put("Success", Server.add_channel_members(chan_id,other_id));
		}//end of else
		send(result);
	}//end of add member to groups
	
	private void remove_member_group(JSONObject data) throws SQLException, IOException {
		int chan_id = ((Long) data.get("channel_id")).intValue();
		int other_id = ((Long) data.get("other_user_id")).intValue();
		JSONObject result = new JSONObject();
		result.put("Status", "remove_member_reply");
		if(!isOwnerChannel(chan_id)) {
			result.put("Success", false);
		}//end of if
		else {
			result.put("Success", Server.remove_channel_members(chan_id,other_id));
		}//end of else
		send(result);
	}//end of remove_member groups
	
	private void remove_group(JSONObject data) throws SQLException, IOException {
		int chan_id= ((Long) data.get("channel_id")).intValue();
		JSONObject result = new JSONObject();
		result.put("Status", "remove_member_reply");
		if(!isOwnerChannel(chan_id)) {
			result.put("Success", false);
		}//end of if
		else {
			result.put("Success", Server.remove_channel(chan_id));
		}//end of else
		send(result);
	}
	
	private void get_user_list(JSONObject data) throws SQLException, IOException {
		ResultSet rs = Server.get_all_user();
		JSONArray info = new JSONArray();
		JSONObject temp;
		if(!rs.isBeforeFirst()) {//doesn't contain any data
			temp = new JSONObject();
			temp.put("Success",false);
			send(temp);
			return;
		}//end of doesn;t contain
		//here we can assume THERE IS data in.
		while(rs.next()){
			temp = new JSONObject();
			temp.put("id",rs.getInt("id"));
			temp.put("username",rs.getString("username"));
			temp.put("status",rs.getInt("status"));
			temp.put("last_seen",rs.getTimestamp("last_seen").getTime());
			temp.put("created_at",rs.getTimestamp("created_at").getTime());
			info.add(temp);
		}//end of while loops
		//once we done putting data inside. we will now put them into one more JSON with success.
		temp = new JSONObject();
		temp.put("Success",true);
		temp.put("data", info);
		send(temp);

	}//end of get all user list
	private String get_author_name(int user_id){
		for(ClientHandler mc: Server.ar){
			if(mc.user_id == user_id) return mc.name;
		}
		return null;
	}
	private JSONObject msg_format(ResultSet rs) throws SQLException {
		/*
		 * Format.
		 * {
		 * 	Status: message_reply
		 * 	Success: boolean (if create or not)
		 * 	id: msg_id
		 * 	author_id: user_id
		 * 	channel_id: chan_id
		 * 	created_at: timestamp
		 * 	content: message content
		 * }
		 */
		JSONObject data = new JSONObject();
		boolean create = rs.isBeforeFirst();
//		ResultSet account = Server.get_account(rs.getInt("author_id"));
		data.put("Status", "message_reply");
		data.put("Success",create);
//		if(!create) return data;
		data.put("id",rs.getInt("id"));
		data.put("author_id",rs.getInt("author_id"));
		data.put("author_name", get_author_name(rs.getInt("author_id")));
		data.put("channel_id",rs.getInt("channel_id"));
		data.put("created_at",rs.getTimestamp("created_at").getTime());
		data.put("content",rs.getString("content"));
		return data;
	}//end of msg_format, we are making template so it is same for rest of time.

	private void send_msg(JSONObject data) throws SQLException, IOException {
		int chan_id = ((Long) data.get("chan_id")).intValue();
		String msg = (String) data.get("content");
		//add msg then create data in.
		ResultSet rs =  Server.add_msg(user_id, chan_id, msg);
		JSONObject result = msg_format(rs);	
		System.out.println(result);
//		boolean create = rs.isBeforeFirst();
//		rs.next();
//		JSONObject result = msg_format(rs);	
		//if it true then we will send to multi channel.
		if((boolean) result.get("Success")) {
			ResultSet chanRS = Server.get_channel_list(chan_id);
			List<Integer> array_id = new ArrayList<Integer>();
			while(chanRS.next()) {
				System.out.println("checking channel " + chanRS.getInt("author_id"));
				//we are getting all list of id that are in that channel.
				array_id.add(chanRS.getInt("author_id"));
			}//end of while
			for(ClientHandler mc: Server.ar) {
				System.out.println("Under user list and it show " + mc.user_id + " and name is " + mc.name);
				if(array_id.contains(mc.user_id)) mc.send(result); 
			}//end of loops
		}//end of if
		else {
			send(result);
		}
	}//end of send message
	private void msg_history(JSONObject data) throws SQLException, IOException {
		int chan_id = ((Long) data.get("chan_id")).intValue();
		ResultSet rs = Server.get_msg_history(chan_id);
		JSONArray info = new JSONArray();
		JSONObject temp;
		if(!rs.isBeforeFirst()) {//doesn't contain any data
			temp = new JSONObject();
			temp.put("Status","message_history_reply");
			temp.put("Success",false);
			send(temp);
			return;
		}//end of doesn;t contain
		//here we can assume THERE IS data in.
		while(rs.next()){
			temp = msg_format(rs);
			info.add(temp);
		}//end of while loops
		//once we done putting data inside. we will now put them into one more JSON with success.
		temp = new JSONObject();
		temp.put("Success",true);
		temp.put("data", info);
		send(temp);

	}//end of getting history msg
	
	private void operations(String received) throws ParseException, SQLException, IOException {
		//it run operations, where it check tasks given and do them.
		JSONParser parser = new JSONParser();
		JSONObject data = (JSONObject) parser.parse(received);
		
		String status = (String) data.get("Status");
		System.out.println(data);
		if(status.equals("login"))login(data);
		else if(status.equals("create_account"))create_account(data);
		else if(status.equals("status_update"))Server.update_account_status(user_id, ((Long)data.get("lvl")).intValue());
		else if(status.equals("create_channel")) create_channel(data);
		else if(status.contentEquals("get_all_group")) get_all_group(data);
		else if(status.contentEquals("get_pm")) get_private_channel(data);
		else if(status.contentEquals("create_group")) create_group(data);
		else if(status.contentEquals("add_member_group")) add_member_group(data);
		else if(status.contentEquals("remove_member_group")) remove_member_group(data);
		else if(status.contentEquals("remove_group")) remove_group(data);
		else if(status.contentEquals("get_user_list")) get_user_list(data);
		else if(status.contentEquals("send_message")) send_msg(data);
		else if(status.contentEquals("message_history")) msg_history(data);
	}//end of operations  that does tasks
	
	@Override
	public void run() { 
		String received; 
		while (true){ 
			try{ 
				// receive the string 
				received = dis.readUTF(); 
				operations(received);
			}catch(SQLException e) {
					e.printStackTrace();
			}catch (IOException e) { 
				signout();//signing out since it couldn't connect which can cause this error.
				break;
			} catch (ParseException e) {
				e.printStackTrace();
			}//end of last catch. 
		}//end of while loops  
	}//end of run 
}//end of class 
