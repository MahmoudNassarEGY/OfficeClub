/*
 * Zayyan Ahmer
 * Client that connect to Server
 * This is also similar as API for UI so that people can just easily enter such as Login etc
 */

package Client;
import java.io.*; 
import java.net.*;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Client 
{ 
	final private static int ServerPort = 1234;
	private String IP_Address;
	public String username;
	private DataInputStream dis;
	private DataOutputStream dos;
	private Content content = new Content();
	public int user_id = 0; // 0 mean not login, There no such ID that is 0
	public List<JSONObject> any_message_recieve = new ArrayList<JSONObject>() ; 
	
	public Client(String ip) {
		this.IP_Address = ip;
		
	}
	
	public boolean connect() throws UnknownHostException, IOException {
		Socket s;
		try {
			s = new Socket(IP_Address, ServerPort);
		}catch(ConnectException e){
			return false;
		}
		
		dis = new DataInputStream(s.getInputStream()); 
		dos = new DataOutputStream(s.getOutputStream()); 
		ReadMessage readMessage = new ReadMessage(dis,content,any_message_recieve);
//		SendMessage sendMessage = new SendMessage(dos,this.username,content);
		
		Thread startThread = new Thread(new Runnable() 
		{ 
			@Override
			public void run() { 
				readMessage.start();
//				sendMessage.start();
				while (true) { 
					try {
						if(readMessage.getState() == Thread.State.TERMINATED) readMessage.start();
//						if(sendMessage.getState() == Thread.State.TERMINATED) sendMessage.start();
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						System.out.println(e);
					}
				} 
			} 
		}); // end of Thread create
		
		startThread.start();
		return true;
	}//end of Connect()
	
	private void isLogin() {
		if(user_id == 0) 
			throw new RuntimeException("Login is require first!");
		}
	
	private JSONObject toJson(){
		System.out.println("Under tojson");
	      JSONParser parser = new JSONParser();
	      System.out.println("Under toJSON AFTER PARSER!");
	      try {
			return (JSONObject) parser.parse(recieve());
		} catch (ParseException e) {
			e.printStackTrace();
		}
	      return null;
	}//end of covert to json
	
	//create login (user,password)
	public boolean login(String email, String pass) {
	      JSONObject data = new JSONObject();
	      data.put("Status","login");
	      data.put("email",email);
	      data.put("Password",pass);
	      if(! send(data)) return false; // something happen soo who knows.
	      System.out.println("Getting data");
	      data = get_recieve();
	      if(data == null) return false;
	      if( (boolean) data.get("success")  ) {
	    	  this.user_id =  ( (Long) data.get("user_id")).intValue();
		  this.username = (String) data.get("username");
	    	  return true;
	      }
	      return false;
	}//end of login 
	
	//create create_account(user,email,password)
	public boolean create_account(String user, String email, String pass) {
		JSONObject data = new JSONObject();
	      data.put("Status","create_account");
	      data.put("Email",email);
	      data.put("Username",user);
	      data.put("Password",pass);
	      if(!send(data)) return false;
	      data = get_recieve(); //we wait for reply and then get JSON object back
	      if(data == null) return false; // failed to get or problems.
	      if( (boolean) data.get("Success")  ) {
	    	  this.user_id =  ( (Long) data.get("User_ID")).intValue();
	    	  return true;
	      }
	      return false;
	}//end of create_account
	
	private int status_convert(String lvl) {
		if(lvl.equals("online")) return 1;
		if(lvl.equals("busy")) return 2;
		if(lvl.equals("afk")) return 3;
		return 0; //offline
	}//end of status_convert
	
	public boolean update_status(String lvl) { //I tried with Enums, but it wasn't having it...
		isLogin();
		System.out.println("Status show  " + lvl );
		JSONObject data = new JSONObject();
		data.put("Status","status_update");
		data.put("lvl",status_convert(lvl));
		return send(data);
	}//end of update status
	
	//create channel()
	//this will have to be called if no such a channel exists between user or wanting to make groups.
	public int create_channel(int other_user_id) {
		//in this method, this is only for channel between two user.
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","create_channel");
		data.put("user_id",user_id);
		data.put("other_user_id",other_user_id);
		if(!send(data)) return 0; //if failed to send or w/e reason.
		data = get_recieve();
		if(data == null) return 0;
		return ((Long) data.get("channel_id")).intValue();
	}//end of create_Channel
	
	//get all access channel()
	public JSONObject get_all_group() {
		//only channel that this ID can view.
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","get_all_group");
		data.put("user_id",user_id);
		if(!send(data)) return null;
		return get_recieve();
	}
	
	public int get_pm(int other_user_id) {
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","get_pm");
		data.put("user_id",user_id);
		data.put("other_id", other_user_id);
		if(!send(data)) return -1;
		data = get_recieve();
		if((boolean) data.get("success")) return (int)data.get("channel_id");
		return -1;
	}
	
	//create group channel
	public int create_group(String name) {
		//in this method, this is only for channel between two user.
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","create_group");
		data.put("user_id",user_id);
		data.put("name",name);
		if(!send(data)) return 0; //if failed to send or w/e reason.
		data = get_recieve();
		if(data == null) return 0;
		return ((Long)data.get("group_id")).intValue();
	}//end of create_Channel
	
	//add member to groups
	public boolean add_member_group(int group_id,int other_id) {
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","add_member_group");
		data.put("user_id",user_id);
		data.put("other_user_id",other_id);
		data.put("channel_id",group_id);
		if(!send(data)) return false; //if failed to send or w/e reason.
		data = get_recieve();
		return (boolean)data.get("Success");
	}
	//delete member from groups
	public boolean remove_member_group(int group_id,int other_id) {
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","remove_member_group");
		data.put("user_id",user_id);
		data.put("other_user_id",other_id);
		data.put("channel_id",group_id);
		if(!send(data)) return false; //if failed to send or w/e reason.
		data = get_recieve();
		return (boolean)data.get("Success");
	}
	//delete groups channel
	public boolean remove_group(int group_id) {
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","remove_group");
		data.put("user_id",user_id);
		data.put("channel_id",group_id);
		if(!send(data)) return false; //if failed to send or w/e reason. such as not owner.
		data = get_recieve();
		return (boolean)data.get("Success");
	}
	//create get_user_list ()
	public JSONObject get_user_list() {
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","get_user_list");
		if(!send(data)) return null;
		return get_recieve();
		//		while(!isRecieve()) {}
//		String msg = recieve();
//	      JSONParser parser = new JSONParser();
//	      System.out.println("Under toget user list AFTER PARSER!");
//	      try {
//			return (JSONArray) parser.parse(msg);
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
//	      return null;
	}
	
	// create send_message (msgID, channelID,msg)
	public boolean send_message(int chan_id, String msg) {
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","send_message");
		data.put("user_id",user_id);
		data.put("chan_id",chan_id);
		data.put("content",msg);
		if(!send(data)) return false;
		return true;
	}
	public JSONObject get_message_history(int chan_id) {
		isLogin();
		JSONObject data = new JSONObject();
		data.put("Status","message_history");
		data.put("chan_id",chan_id);
		if(!send(data)) return null;
		return get_recieve();
	}//end of get message history from this chan
	

	public JSONObject get_recieve() {
		//Reason is like this, so we dont miss early recieve if user does recieve, e.g we didnt call and someone send message
		//we will missed it so that why there is that thread that will run background while this here exists.
		System.out.println("Getting recieve....");
		int i = 0;
		int counter = 0;
		while(!isRecieve()) {
			if( i++ >= 1000000) { //debuging to check if it actually stuck in loops...
				i = 0;
				counter++;
				System.out.println("still there waiting for recieve. " + counter);
			}
		} //wait till it return true then exists
		System.out.println("Existing loops and getting to json");
		return toJson();
	}//end of await get recieve function and return json.
	
	private boolean send(JSONObject data) { // I don t need to make thread for this, i can just send...
		try {
			System.out.println("Sending message show "  + data.toJSONString());
			System.out.println("DOS show " + dos);
			dos.writeUTF(data.toJSONString());
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}//end of send
	
	public boolean isRecieve() {return content.isRecieve;}
	
	public String recieve() {
		if(!content.isRecieve) return null;
		content.isRecieve = false;
		return content.Recieve;	
	}//end of recieve method.
	
	public boolean is_reply_back(){return !any_message_recieve.isEmpty();}
	
	public JSONObject get_message(){return any_message_recieve.remove(0);}
	
}//end of Client class
	

class Content{
	String Recieve;
	boolean isRecieve;
}

class ReadMessage extends Thread{
	DataInputStream dis; Content cnt; List<JSONObject> msg_reply;
	Window1 chat_box;
	public ReadMessage(DataInputStream dis,Content cnt,List reply_msg) {
		this.dis = dis;
		this.cnt = cnt;
		this.msg_reply = reply_msg;
	}
	public void run(){  
		System.out.println("thread is running...");
		while(true) {
			try { 
				// read the message sent to this client 
				System.out.println("Under client " + msg_reply);
				String msg = dis.readUTF(); 
				JSONObject data = null;
			      JSONParser parser = new JSONParser();
			      System.out.println("Under toJSON AFTER PARSER!");
			      try {
					data = (JSONObject) parser.parse(msg);
				} catch (ParseException e) {
					e.printStackTrace();
				}
		        if(data != null && data.get("Status") != null && ((String)data.get("Status")).contains("message_reply")){
		        	System.out.println("Client has recieved message + " + data);
		        	msg_reply.add(data);
//		        	System.out.println(data.hashCode());
		        }
		        else{
				    cnt.isRecieve = true;
					cnt.Recieve = msg;
					System.out.println("Existing run");
		        }
			} catch (IOException e) { 
				//e.printStackTrace();
				System.out.println("Problem with server");
				return;
//				try {
//					Thread.sleep(5000);
//				} catch (InterruptedException e1) {
//					continue;
//				};
			}//end of catch.
		}//end of while loops
	}//end of run
}//end of class.

