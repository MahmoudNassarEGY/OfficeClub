package Client;

import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class WindowSMS extends Stage {

	ScrollPane conversation; // Pane where all the conversations are being displayed
	ScrollPane onlinePeeps; // Pane to display all the online users

	TextField txtName; // Display the user name at the bottom left
	TextField txtInput; // textField to send messages.

	TextArea chat; // area to display the conversations on the conversation ScrollPane

//	DataOutputStream output = null;
//	LoginPage pg = new LoginPage();
	 public void LoginPage(Stage primaryStage, String user) {
	    	
	    }

	public WindowSMS(Stage primaryStage, String user) {

		BorderPane bp = new BorderPane(); // used to display everything on the scene

		conversation = new ScrollPane();
		chat = new TextArea();
		chat.setEditable(false);

		conversation.setContent(chat);
		conversation.minWidth(615);
		// conversation.setPrefWidth(615);
		conversation.setFitToHeight(true);
		conversation.setFitToWidth(true);

		VBox vBoxConv = new VBox();
		vBoxConv.getChildren().addAll(conversation);
		// vBoxConv.setVgrow(conversation, Priority.ALWAYS);
		bp.setCenter(conversation);

		// Creating a ToggleGroupa
		ToggleGroup group = new ToggleGroup();

		// Array list to hold all the online user name.
		ArrayList<String> onlineUserNames = new ArrayList<String>();
		onlineUserNames.add("Zayaan");
		onlineUserNames.add("selam");
		onlineUserNames.add("Csan");
		onlineUserNames.add("Mahmoud");
		onlineUserNames.add("james");
		onlineUserNames.add("Mike");
		onlineUserNames.add("abdulla");
		onlineUserNames.add("ahmed");
		
		onlineUserNames.add("joseph");
		onlineUserNames.add("tekle");

		// Create an array list to hold the toggle button for each online user
		ArrayList<ToggleButton> onlinePeople = new ArrayList<ToggleButton>();

		for (int i = 0; i < onlineUserNames.size(); i++) 
			onlinePeople.add(new ToggleButton(onlineUserNames.get(i)));
	
		
	
//		ToggleButton user1 = new ToggleButton("name1");
//		onlinePeople.add(user1);
//
//		ToggleButton user2 = new ToggleButton("name2");
//		onlinePeople.add(user2);
//
//		ToggleButton user3 = new ToggleButton("name3");
//		onlinePeople.add(user3);
//
//		ToggleButton user4 = new ToggleButton("Name4");
//		onlinePeople.add(user4);
//
//		ToggleButton user5 = new ToggleButton("name5");
//		onlinePeople.add(user5);
//
//		ToggleButton user6 = new ToggleButton("name6");
//		onlinePeople.add(user6);
//
//		ToggleButton user7 = new ToggleButton("Name7");
//		onlinePeople.add(user7);
//
//		ToggleButton user8 = new ToggleButton("name8");
//		onlinePeople.add(user8);
//
//		ToggleButton user9 = new ToggleButton("name9");
//		onlinePeople.add(user9);
//
//		ToggleButton user10 = new ToggleButton("name10");
//		onlinePeople.add(user10);

		for (int i = 0; i < onlinePeople.size(); i++) {
			onlinePeople.get(i).setMinWidth(185);
			onlinePeople.get(i).setToggleGroup(group);
		}

//        onlinePeople.get(0).setToggleGroup(group);
//        onlinePeople.get(1).setToggleGroup(group);
//        onlinePeople.get(2).setToggleGroup(group);

		
		VBox vBoxUsers = new VBox();
		vBoxUsers.getChildren().addAll(onlinePeople);
		// vBoxUsers.setVgrow(onlinePeeps, Priority.ALWAYS);

		onlinePeeps = new ScrollPane();
		// people = new TextArea();
		// people.setEditable(false);

		// onlinePeeps.setContent(people);
		onlinePeeps.setPrefWidth(187);
		onlinePeeps.setFitToWidth(true);
		onlinePeeps.setFitToHeight(true);
		onlinePeeps.setContent(vBoxUsers);

		// vBoxUsers.getChildren().addAll(onlinePeeps);
		// vBoxUsers.prefHeight(50);
		bp.setLeft(onlinePeeps);

		txtName = new TextField();
		txtName.setText(user.toUpperCase());
		txtName.setEditable(false);
		txtName.setAlignment(Pos.BASELINE_CENTER);

		txtInput = new TextField();
		txtInput.setPromptText("New message");
		txtInput.setTooltip(new Tooltip("Write your message. "));

		Button btnSend = new Button("Send");
		btnSend.setOnAction(new ButtonListener());

		HBox hBox = new HBox();
		hBox.getChildren().addAll(txtName, txtInput, btnSend);
		HBox.setHgrow(txtInput, Priority.ALWAYS);

		bp.setBottom(hBox);

		onlinePeople.get(0).setOnAction(e -> {
			chat.setText("thats goodE");

		});

		onlinePeople.get(1).setOnAction(e -> {
			chat.setText("now??");

		});

		onlinePeople.get(2).setOnAction(e -> {
			chat.setText("lol");

		});

		onlinePeople.get(3).setOnAction(e -> {
			chat.setText("you are good bro");

		});

		onlinePeople.get(4).setOnAction(e -> {
			chat.setText("take care");

		});

		onlinePeople.get(5).setOnAction(e -> {
			chat.setText("he is upto someting.");

		});

		onlinePeople.get(6).setOnAction(e -> {
			chat.setText("technical");

		});

		onlinePeople.get(7).setOnAction(e -> {
			chat.setText(" this is bulshit");

		});

		onlinePeople.get(8).setOnAction(e -> {
			chat.setText("what a day");

		});

		onlinePeople.get(9).setOnAction(e -> {
			chat.setText("love this");

		});
		
		Button logout = new Button("Logout");
		HBox hBox1 = new HBox();
		hBox1.setAlignment(Pos.TOP_RIGHT);
//		logout.setAlignment(Pos.TOP_RIGHT);
		hBox1.getChildren().addAll(logout);
		
		bp.setTop(hBox1);
		logout.setOnAction(e->{
	//		new LoginPage().start(primaryStage);
			this.close();
		});

//		btnSend.setOnAction(e->{
//			chat.appendText("\n"+txtInput.getText());
//			txtInput.clear();
//		});

		this.setScene(new Scene(bp, 800, 800));
		this.setTitle("SMS Window");
		this.show();

		// Create a socket to connect to the server

	}

	public WindowSMS(Client cl) {
		// TODO Auto-generated constructor stub
	}

	public WindowSMS(Stage primaryStage, Client cl) {
		// TODO Auto-generated constructor stub
	}

	private class ButtonListener implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent e) {
			try {
				// get username and message
				String username = txtName.getText().trim();
				String message = txtInput.getText().trim();

				// if message is empty don't send the message
				if (message.length() == 0) {
					return;
				}

				// send message to server
				// System.out.println("[" + username + "]: " + message + "");

				chat.appendText("\n[" + username + "]: " + message);

				// clear the textfield
				txtInput.clear();
			} catch (Exception ex) {
			}

		}
	}

	public void start(Stage stage) {
		// TODO Auto-generated method stub
		
	}
}