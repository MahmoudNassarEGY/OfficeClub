package Client;

import java.io.IOException;
import java.net.UnknownHostException;

public class Start {
	public static void main(String[] args) throws UnknownHostException, IOException {
		Client c1 = new Client("127.0.0.1");
		boolean isconnect =  c1.connect();
		if(!isconnect) {
			System.out.println("Not connect...");
			return;
		}
		
		if(!c1.login("lad1@man","lad1")) c1.create_account("wew1", "lad1@man", "lad1"); //if failed to login, then create new account.
		System.out.println("Now we will login ");
		c1.update_status("online");
//		c1.create_channel(1);
//		System.out.println(c1.get_all_group());
//		System.out.println("sending message and it show us " + c1.send_message(7,"Hi there!"));
//		System.out.println("Getting history of msg show " + c1.get_message_history(7));

	}

}
