package Client;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.*;
public class OfficeClub {
public static void main (String[]Args){
	InitUI();
}

static void InitUI(){
	Display display = new Display();
	Shell shell = new Shell(display);
	Button button1 = new Button(shell , SWT.PUSH);
	button1.setText("close");
	button1.setBounds(75, 40, 80, 30);
	
	Button button2 = new Button(shell , SWT.PUSH);
	button2.setText("cancel");
	button2.setSize(80,30);
	button2.setLocation(75,75);
	
	shell.setText("Office Club");
	shell.setSize(300,300);
	shell.open();
	
	while (!shell.isDisposed()){
		if (!display.readAndDispatch()){
			display.sleep();
		}
	}
	
	
}
}
