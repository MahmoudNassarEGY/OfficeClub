package Client;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

import java.awt.Event;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import java.sql.*;
import org.eclipse.swt.widgets.Text;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.events.*;
public class UsersList implements ActionListener{
	private static Text text;

	/**
	 * Launch the application.
	 * @param args
	 * @throws IOException 
	 * @throws UnknownHostException 
	 */
	public static void main(String[] args) throws UnknownHostException, IOException {
		Client client = new Client("127.0.0.1");
		client.connect();
//		client.create_account("wewlad", "email2dfq3", "pass2");
		client.login("email2","pass2");
		JSONObject data = client.get_user_list();
		JSONArray array_data = (JSONArray) data.get("data");
		JSONObject temp;
		System.out.println(data);
		
		Display display = Display.getDefault();
		Shell shell = new Shell();
		shell.setSize(287, 362);
		shell.setText("Office Club");
		shell.setLayout(null);
		Color darkgray = display.getSystemColor(SWT.COLOR_DARK_GRAY);
		Color gray = display.getSystemColor(SWT.COLOR_GRAY);
		Color black = display.getSystemColor(SWT.COLOR_BLACK);
		shell.setBackground(black);
		
		//InputStream input = Button.class.getResourceAsStream("/ChatList/src/OfficeClub.PNG");
		
		Label lblMahmoud = new Label(shell, SWT.NONE);
		lblMahmoud.setBounds(0, 0, 71, 21);
		lblMahmoud.setText(client.username);
		//Image image = new Image(null,input);
	//	lblMahmoud.setImage(image);
		
		
		
		Combo combo = new Combo(shell, SWT.DROP_DOWN);
		String[] items = new String[]{"Online","Offline","Busy"};
		combo.setBounds(65, -3, 91, 23);
		combo.setBackground(darkgray);
		combo.setItems(items);
		combo.setText("Set Status");
		combo.addSelectionListener(new SelectionAdapter() {
			 public void widgetSelected(SelectionEvent e) {
			  int idx = combo.getSelectionIndex();
              String status = combo.getItem(idx);
              client.update_status(status.toLowerCase());
			 }
		});
		Button btnCreateAGroup = new Button(shell, SWT.PUSH);
		btnCreateAGroup.setBounds(155, -4, 79, 25);
		
		btnCreateAGroup.setBackground(darkgray);
		btnCreateAGroup.setText("Create Group ");
		String[] items2 =  new String[] {" skcjn","jabsddi"};
		temp = (JSONObject) array_data.get(0);
		String usrx =((String)temp.get("username"));
		items2[0]=usrx;//);
		temp = (JSONObject) array_data.get(1);
		String usry =((String)temp.get("username"));
		items2[1]=usry;//((String)temp.get("username"));
	 
		btnCreateAGroup.addListener(SWT.Selection, new Listener()
		{ 
		  
//Creating a group button
			@Override
			public void handleEvent(org.eclipse.swt.widgets.Event event) {
				// TODO Auto-generated method stub
				  System.out.println("Creating a group code goes here");
				
				/*  Group grp = new Group(shell, SWT.NONE);
					grp.setText("Enter informaion about the group");
					grp.setBounds(10, 117, 196, 82);
					
					*/
				
					
				  text = new Text(shell, SWT.NONE);
					text.setBounds(10, 128, 150, 21);
					text.setBackground(darkgray); 
					text.setText("Enter the group name here");
					//textHandltextHandler.accept(t.getText());
					Combo combo2 = new Combo(shell, SWT.DROP_DOWN);
					
					combo2.setBounds(10, 150, 150, 21);
					combo2.setBackground(darkgray);
					combo2.setItems(items2);
					combo2.setText("Add to group");
					combo2.addSelectionListener(new SelectionAdapter() {
						 public void widgetSelected(SelectionEvent e) {
						  int idx = combo2.getSelectionIndex();
			              String usr = combo2.getItem(idx);
			              System.out.print(usr);
			              
						 }
					});
					
					Button btnnamegrp= new Button(shell, SWT.PUSH);
					btnnamegrp.setBounds(180, 128, 90, 20);
					
					btnnamegrp.setBackground(darkgray);
					btnnamegrp.setText("Create Group ");
				 
					btnnamegrp.addListener(SWT.Selection, new Listener()
					{ 
					  

						@Override
						public void handleEvent(org.eclipse.swt.widgets.Event event) {
					String x = text.getText();
					client.create_group(x);
					System.out.println("that group was created: "+x);
						}
					});
					

			}
		});
		
		Menu list = new Menu(shell, SWT.BORDER);
		
		list.setLocation(0, 27);
		
		
		 MenuItem newItem = new MenuItem(list, SWT.NONE);
		    newItem.setText("New");
		
		    
		int x= 25;
		Label [] lblList = new Label[array_data.size()];
		for(int i = 0; i < array_data.size();i++){
			temp = (JSONObject) array_data.get(i);
			System.out.println(i + " The ID IS " + temp.get("id") + " and username " +
			temp.get("username"));
			Label lblUser = new Label(shell, SWT.NONE);
			lblUser.setBounds(0, 52+x*i, 55, 15);
			lblUser.setText((String)temp.get("username"));
			//event should be here I THINK, with passing ID of user, once u get user ID, 
			//and confirm it is indeed user, then get a channel ID by calling that method
			lblList[i] = lblUser;
		}
		System.out.println(lblList);
		
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		 
		// TODO Auto-generated method stub
		
	}
}
