package Client;

//import Client;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javafx.animation.Animation.Status;
import javafx.collections.SetChangeListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import javax.swing.JMenu;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Scrollbar;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.List;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JComboBox;

import org.json.simple.JSONObject;

public class Window1 extends JFrame {
	static String friend_username;
	private JPanel contentPane;
	static Client client;
	static int chan_id;
	
    private javax.swing.JLabel label1; //variables
    private javax.swing.JLabel status;
	private static javax.swing.JTextArea display1;
	private javax.swing.JButton send1;
	static javax.swing.JTextArea text1;

	public Window1(String username,Client client, int chan_id){
		friend_username = username;
		this.client = client;
		this.chan_id = chan_id;
	}
	public static void main(String[] args) throws UnknownHostException, IOException {
	client = new Client("127.0.0.1");
	client.connect();
	client.login("win1","win");
	chan_id = 1;
//	username1 = client.username;
	Window1 win = new Window1("Win2",client,1);
	win.run();
	}
	public static void run(){
		
		//client.create_account("win2","win2","win");

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window1 frame = new Window1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Window1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 453, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		final JTextArea display1 = new JTextArea();
		display1.setBounds(15, 41, 417, 282);
		contentPane.add(display1);
		
		final JTextArea Status = new JTextArea();
		Status.setBounds(15, 44, 401, 250);
		getContentPane().add(Status);
		
		final JTextArea text1 = new JTextArea();
		text1.setBounds(15, 341, 269, 55);
		getContentPane().add(text1);
		
		//run the thread here so we can recieve message.
		Checking_message msg_event = new Checking_message(display1,client,friend_username);
		msg_event.start();
		
		JButton send1 = new JButton("SEND");
		send1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) { //code
				
					String s = text1.getText();
					if(s.equals("")){
						return;
					}
					client.send_message(chan_id,s);
//					JSONObject data = client.send_message(chan_id, s);
//					System.out.println(data);
//					if((boolean) data.get("Success")){
//						text1.setText("");
//						System.out.println("we got the message");
//						display1.append(((Long)data.get("author_id")).toString() +":" + (String) data.get("content") + "\n" );
//
//					}
					//Window2.sendText();
					text1.setText("");
					
			}
		});
		send1.setBounds(301, 347, 115, 49);
		getContentPane().add(send1);
		
		JLabel label1 = new JLabel(friend_username);
		label1.setBounds(15, 4, 115, 20);
		getContentPane().add(label1);
		
		JButton clear = new JButton("CLEAR");
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Status.setText("");
			}
		});
		clear.setBounds(301, 0, 115, 29);
		getContentPane().add(clear);
		
		Scrollbar scrollbar = new Scrollbar();
		scrollbar.setBounds(395, 152, 26, 50);
		getContentPane().add(scrollbar);
		
		
		
	
		
		
			
			JComboBox comboBox = new JComboBox(new Object[] {"Online", "Offline", "Busy"});
			comboBox.setEditable(true);
			JTextComponent editor = (JTextComponent) comboBox.getEditor().getEditorComponent();
			
			comboBox.setBounds(145, 2, 139, 26);
			getContentPane().add(comboBox);
			add(comboBox);
	}
		
		
	
	

	public void recieve_msg(JSONObject data){
		display1.append(friend_username +":" + (String) data.get("content") + "\n" );

	}

}//end of class Window

class Checking_message extends Thread{
	javax.swing.JTextArea text_field;
//	private List<JSONObject> reply_list;
	Client client;
	String friend_username;
	public Checking_message(javax.swing.JTextArea d,Client client,String FU) {
		this.text_field = d;
//		this.reply_list = reply_list;
		this.client = client;
		this.friend_username = FU;
	}
	public void run(){  
		System.out.println("thread is running...");
		while(true) {
			//while(!Window1.client.isRecieve()){}
			//JSONObject data = Window1.client.get_recieve();
//			System.out.println(client.is_reply_back());
//			System.out.println("under window " + client.any_message_recieve);
//			System.out.println("yup");
//			System.out.println(client.any_message_recieve.hashCode());
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(client.is_reply_back()){
				JSONObject data = client.get_message();
				text_field.append(friend_username +":" + (String) data.get("content") + "\n" );
			}
			
		}//end of while loops
	}//end of run
}//end of class.



