package OfficeClub;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
  

public class LoginPage extends Application {
  
 String email = "";
 String pw = "";
 String checkUser, checkPw;
// Stage mainPage;
 Scene loginPage, registrationForm, userMenue, textWindow;
  
    public static void main(String[] args)throws exceptions {
        Client client = new Client("127.0.0.1","username");
    	launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
    	 
    	//  mainPage= primaryStage;
    	  
        BorderPane bp = new BorderPane();
        bp.setPadding(new Insets(10,50,50,50));
         
        //Adding HBox
        HBox hb = new HBox();
        hb.setPadding(new Insets(20,20,20,30));
         
        //Adding GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20,20,20,20));
        gridPane.setHgap(5);
        gridPane.setVgap(5);
         
        // adding labels and textfieled for account login
        Label lblUserName = new Label("Email");
        final TextField txtUserName = new TextField();
        Label lblPassword = new Label("Password");
        final PasswordField pf = new PasswordField();
        Button btnLogin = new Button("Login");
   //     btnLogin.setOnAction(this);
        
        
        Label lblNewUser = new Label("New? Create Account"); 
        Button btCreate = new Button("Create");
        btCreate.setOnAction(e-> {
        	primaryStage.close();
        	new RegForm().start(new Stage());
        }); //links to newUser page
        
        final Label lblMessage = new Label();
        
        //adding the labels and and textfild into gridPane
        gridPane.add(lblUserName, 0, 2);  //puts the node into columns and rows-index
        gridPane.add(txtUserName, 1, 2);  
        gridPane.add(lblPassword, 0, 3);  
        gridPane.add(pf, 1, 3);         
        gridPane.add(btnLogin, 4, 3);    									
        gridPane.add(lblNewUser, 5, 5);
        gridPane.add(btCreate, 6, 5);
        gridPane.add(lblMessage, 3, 6); 
        
        /*Reflection for gridPane (creates a reflection of nodes/displays 
        that are placed in pane as specified */
        Reflection r = new Reflection();
        r.setFraction(0.7f);
        gridPane.setEffect(r);
         
        //DropShadow effect 
        DropShadow dropShadow = new DropShadow();
        dropShadow.setOffsetX(5);
        dropShadow.setOffsetY(5);
         
        //Adding text and DropShadow effect to it
        Text text = new Text("Please <login> to connect!");
        text.setFont(Font.font("Courier New", FontWeight.BOLD, 28));
        text.setEffect(dropShadow);
                
        //Adding text to HBox
        hb.getChildren().add(text);
                           
        //Add ID's to Nodes for the login.css file for better styling
        bp.setId("bp");
        gridPane.setId("root");
        btnLogin.setId("btnLogin");
        text.setId("text");
        btCreate.setId("create");
        lblNewUser.setId("lableText");         
        //Action for btnLogin button need to link with data
       btnLogin.setOnAction(new EventHandler() {
        
         public void handle(ActionEvent event) {
          checkUser = txtUserName.getText().toString();
          checkPw = pf.getText().toString();
          if(checkUser.equals(validEmail()) && checkPw.equals(validPw)){  // include code for accesiing the server to get respond
        
        	  
        	  
          }
//          
//        	  lblMessage.setText("You are connected!");
//           lblMessage.setTextFill(Color.GREEN);
//  //         primaryStage.close();
//  //         new userWindow().start(new Stage());
//           // chat window loaded    
//          }
//          else{
//           lblMessage.setText("Incorrect user or password.");
//           lblMessage.setTextFill(Color.RED);
//          }
//          txtUserName.setText("");
//          pf.setText("");
//         }
//        });
          
          
          public boolean validEmail() {
        	  
          }
        
      //Action for btCreate
   //     btCreate.setOnAction(new EventHandler() {
        	
   //         public void handle(ActionEvent event) {
        
        //Add HBox and GridPane layout to BorderPane Layout
        bp.setTop(hb);
        bp.setCenter(gridPane);  
     
   
        //Adding BorderPane to the scene and loading CSS 
     Scene scene = new Scene(bp);
   
     scene.getStylesheets().add(getClass().getClassLoader().getResource("login.css").toExternalForm());
     primaryStage.setScene(scene);
      //making the stage resizeable
       primaryStage.titleProperty().bind(
                 scene.widthProperty().asString().
                 concat(" : ").
                 concat(scene.heightProperty().asString()));
     //primaryStage.setResizable(false);
     primaryStage.show();
    }
}
       
       